//
//  AppDelegate.h
//  SharePodsDemoPhone
//
//  Created by 钱国强 on 17/1/8.
//  Copyright © 2017年 Qian GuoQiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

