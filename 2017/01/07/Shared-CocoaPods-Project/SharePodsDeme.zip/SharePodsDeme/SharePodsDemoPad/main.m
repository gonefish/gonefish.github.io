//
//  main.m
//  SharePodsDemoPad
//
//  Created by 钱国强 on 17/1/8.
//  Copyright © 2017年 Qian GuoQiang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
